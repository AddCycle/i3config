from pathlib import Path
from shutil import move

class Consumable:
    """
    A class used to represent a consumable.

    Attributes:
        - name: consumable's name.
        - path: path to consumable's file.
        - attack: consumable's attack points.
        - regen: consumable's regen points.
        - durability: consumable's durability points.
        - path: path to consumable's file
    """

    def __init__(self,
                 name: str,
                 attack: int,
                 regen: int,
                 durability: int,
                 path: Path):
        """
        Create a consumable object.

        Parameters:
            - name: consumable's name.
            - attack: consumable's attack points.
            - regen: consumable's regeneration amount.
            - durability: available usages of consumable before it breaks.
            - path: path to consumable file.

        Returns:
            - created consumable object.
        """
        pass # FIXME

    def delete(self) -> None:
        """
        Delete consumable file.
        """
        pass # FIXME

    def pretty_print(self) -> None:
        """
        Pretty print consumable's information.
        """
        pass # FIXME

    def save(self) -> None:
        """
        Save the consumable.
        """
        pass # FIXME

    def move_to_room(self, room: "Room") -> None:
        """
        Move consumable to the given room.

        Parameters:
            - room: room where the consumable should be moved.
        """
        pass # FIXME

    def use(self) -> bool:
        """
        Use the given consumable.
        If the given consumable is depleted after this use, delete its file.

        Returns:
            - whether the consumable has been depleted (True) or not (False).
        """
        pass # FIXME

def load(path: Path) -> Consumable | None:
    """
    Build a new consumable from a path.

    Parameters:
        - path: path to the consumable file

    Returns:
        - the built consumable. None if the given path does not correspond to a
        valid consumable.
    """
    pass # FIXME
