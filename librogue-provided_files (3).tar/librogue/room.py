from pathlib import Path

from . import enemy as libenemy
from . import consumable as libconsumable


class Room:
    """
    A class used to represent a room.
    Rooms contain enemies, consumables, and subrooms.

    Attributes:
        - name: room name.
        - path: path to room directory.
        - enemies: list of enemies in the room.
        - consumables: list of consumables in the room.
        - subrooms: list of rooms in the room.
    """

    def __init__(self,
                 name,
                 path: Path,
                 enemies: list[libenemy.Enemy] = None,
                 consumables: list[libconsumable.Consumable] = None,
                 subrooms: list["Room"] = None,
                 ):
        """
        Create a room object.

        Parameters:
            - name: room name.
            - path: path to room directory.
            - enemies: list of enemies in the room.
            - consumables: list of consumables in the room.
            - subrooms: list of rooms in the room.

        Returns:
            - created room object.
        """
        pass # FIXME

    def add_room(self, name: str) -> "Room":
        """
        Add a subroom to the room.

        Parameters:
            - name: name of the subroom to add.

        Returns:
            - the created room.
        """
        pass # FIXME

    def add_consumable(self, name: str, attack: int, regen: int,
                       durability: int) -> libconsumable.Consumable:
        """
        Add a newly constructed consumable to the room.

        Arguments:
            - name: consumable's name.
            - attack: consumable's attack points.
            - regen: consumable's regen points.
            - durability: consumable's durability

        Returns:
            - the created consumable
        """
        pass # FIXME

    def add_enemy(self, name: str, attack: int, health: int) -> libenemy.Enemy:
        """
        Add a newly constructed enemy to the room.

        Arguments:
            - name: enemy's name.
            - attack: enemy's attack points.
            - health: enemy's health points.

        Returns:
            - the created enemy
        """
        pass # FIXME

    def remove_enemy(self, enemy: libenemy.Enemy) -> None:
        """
        Remove an enemy from the room.
        """
        pass # FIXME

    def pretty_print(self):
        """
        Print the contents of a room and all its subrooms.
        """
        pass # FIXME

    def loot(self) -> list[libconsumable.Consumable]:
        """
        Loot the room and gather its consumables.

        Returns:
            - a list containing the consumables in the room.
        """
        pass # FIXME

    def save(self, path: Path) -> None:
        """
        Save the room to the given path.

        Parameters:
            - path: path where the room should be saved.
        """
        pass # FIXME



def load(path: Path) -> Room | None:
    """
    Build a new room from a path.

    Parameters:
        - path: path containing the first room.

    Returns:
        - the built room containing all subrooms, consumables, enemies.
        - None if the given path does not correspond to a valid room.
    """
    pass # FIXME
