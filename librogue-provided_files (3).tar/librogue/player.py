from __future__ import annotations
from . import enemy as libenemy
from . import player as libplayer
from . import consumable as libconsumable
from . import room as libroom
from pathlib import Path
from shutil import move

class Player:
    """
    A Class used to represent the player.

    Attributes:
        - name: player's name.
        - health: player's health points.
        - current_room: player's current room.
        - path: path to player file.
        - consumables: list of player's consumables
    """

    def __init__(self,
                 name: str,
                 health: int,
                 starting_room: libroom.Room):
        """
        Create the Player.

        Parameters:
            - name: player name.
            - health: player's health points.
            - starting_room: room in which the player starts.

        Returns:
            - created player object.
        """
        pass # FIXME

    def pretty_print(self):
        """
        Pretty print player information.
        """
        pass # FIXME

    def save(self) -> None:
        """
        Save the player file to their current room's path.

        Parameters:
            - path: path where the player file should be saved
        """
        pass # FIXME

    def delete(self) -> None:
        """
        Delete player file.
        """
        pass # FIXME

    def enter_room(self, room: libroom.Room) -> None:
        """
        Loot current room, enter next room.
        Don't forget your consumables in the old room!

        Parameters:
            - room: room to enter.
        """

        pass # FIXME

    def heal(self, consumable: libconsumable.Consumable) -> None:
        """
        Heal the player with the given consumable.
        If the consumable breaks, remove it from the player's inventory.

        Parameters:
            - consumable: consumable to heal the player with.
        """
        pass # FIXME

    def attack(self, enemy: libenemy.Enemy, consumable: libconsumable.Consumable) -> bool:
        """
        Attack a given enemy with a given consumable.
        If the consumable breaks, remove it from player's inventory.

        Parameters:
            - enemy: enemy to attack.
            - consumable: consumable to attack enemy with.

        Returns:
            - whether the enemy has died (True) or not (False).
        """
        pass # FIXME

    def take_damage(self, attack: int) -> bool:
        """
        Take damage.
        If the player dies, remove its file.

        Parameters:
            - attack: attack points to damage the player.

        Returns:
            - whether the player died (True) or not (False).
        """
        pass # FIXME


def load(path: Path, room: libroom.Room) -> Player | None:
    """
    Build a new player from a path and the corresponding room.

    Parameters:
        - path: path containing the player's room.
        - room: corresponding room.

    Returns:
        - the built player. None if the given path does not correspond to a
        valid player.
    """
    pass # FIXME


def find_player_from_room(room: libroom.Room) -> libplayer.Player | None:
    """
    Find the player file.

    Parameters:
        - room: top room to start searching from.

    Returns:
        - the loaded player file. None if no player file was found.
    """
    pass # FIXME
