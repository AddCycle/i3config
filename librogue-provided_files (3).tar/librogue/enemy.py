from pathlib import Path
from . import player as libplayer


class Enemy:
    """
    A class used to represent an enemy.

    Attributes:
        - name: enemy's name.
        - attack: enemy's attack points.
        - health: enemy's health points.
        - path: path to enemy file.
    """

    def __init__(self,
                 name: str,
                 attack: int,
                 health: int,
                 path: Path):
        """
        Create an enemy object.

        Parameters:
            - name: enemy's name.
            - attack: enemy's attack points.
            - health: enemy's health points.
            - path: path to enemy file.

        Returns:
            - created enemy object.
        """
        pass # FIXME

    def delete(self) -> None:
        """
        Delete enemy file.
        """
        pass # FIXME

    def pretty_print(self) -> None:
        """
        Pretty print enemy's information.
        """
        pass # FIXME

    def save(self) -> None:
        """
        Save the enemy.
        """
        pass # FIXME

    def take_damage(self, attack: int) -> bool:
        """
        Take damage.
        If enemy's health is equal or less than 0, delete its file.

        Parameters:
            - attack: attack point to damage the enemy with.

        Returns:
            - whether the enemy has died (True) or not (False).
        """
        pass # FIXME

    def attack_player(self, player: libplayer.Player) -> bool:
        """
        Attack the player.

        Returns:
            - whether the player died (True) or not (False).
        """
        pass # FIXME

def load(path: Path) -> Enemy | None:
    """
    Build a new Enemy from a file.

    Parameters:
        - path: path to the enemy file.

    Returns:
        - the built Enemy. None if the given path does not correspond to a
        valid enemy.
    """
    pass # FIXME
