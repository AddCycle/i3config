from InquirerPy import inquirer
from InquirerPy.base.control import Choice
from InquirerPy.validator import PathValidator
from pathlib import Path
from librogue import room as libroom, player as libplayer, consumable as libconsumable


def inquire_game_path() -> Path:
    """
    Get the game path from user.
    """
    home_path = Path.cwd().as_posix()

    return Path(inquirer.filepath(
        message="Welcome to ACUdivers! Please input" +
        " the path of the terrain.\n",
        default=home_path,
        validate=PathValidator(
            is_dir=True, message="Oops! This is not a valid path."),
        only_directories=True,
    ).execute())


def attack(player: libplayer.Player) -> bool:
    """
    Handle the attack action.

    Returns:
        - whether the attack was successful.
        He cannot attack if: no consumables, no enemy to attack
    """
    enemies = []
    for index, enemy in enumerate(player.current_room.enemies):
        enemy.pretty_print()
        enemies.append(Choice(index, name=f"{enemy.name}"))

    if len(enemies) == 0:
        print("There is no enemy to attack! Cancelling attack.")
        return False

    print()
    enemies.append(Choice(-1, name="Cancel attack"))
    enemy_index = inquirer.select(
        message="Which enemy do you want to attack?",
        choices=enemies,
    ).execute()

    # cancelling attack
    if enemy_index == -1:
        return False

    weapons = []

    print()
    for index, weapon in enumerate(player.consumables):
        weapon.pretty_print()
        weapons.append(Choice(index, name=f"{weapon.name}"))

    if len(weapons) == 0:
        print("You do not have any consumables! Cancelling attack.")
        return False

    print()
    weapons.append(Choice(-1, name="Cancel attack"))
    weapon_index = inquirer.select(
        message="Which consumable do you want to use to attack?",
        choices=weapons,
    ).execute()

    # cancelling attack
    if weapon_index == -1:
        return False

    enemy_name = player.current_room.enemies[enemy_index].name
    weapon_name = player.consumables[weapon_index].name

    print(f"\n{player.name} is attacking {enemy_name} with {weapon_name}.")

    if player.attack(player.current_room.enemies[enemy_index],
                     player.consumables[weapon_index]):
        print(f"{player.name} has slained {enemy_name}!")

    return True


def enemy_peek(player: libplayer.Player) -> bool:
    """
    Pretty print all enemies in a room.

    Returns:
        - Always false. Peeking is not a valid action to end a round.
    """
    print()

    if len(player.current_room.enemies) == 0:
        print("There are no enemies here!")
        return False

    for enemy in player.current_room.enemies:
        enemy.pretty_print()

    return False


def subroom_peek(player: libplayer.Player) -> bool:
    """
    Print all subrooms' names.

    Returns:
        - Always false. Peeking is not a valid action to end a round.
    """

    if len(player.current_room.subrooms) == 0:
        print("There are no rooms to go in! You are stuck...")
        return False

    for subroom in player.current_room.subrooms:
        print(subroom.name)

    return False


def player_peek(player: libplayer.Player) -> bool:
    """
    Pretty print player information.

    Returns:
        - Always false. Peeking is not a valid action to end a round.
    """
    player.pretty_print()
    return False


def move(player: libplayer.Player) -> bool:
    """
    Handle the move action.

    Returns:
        - Whether the player has moved or not.
        He cannot move if: no subrooms, still alive enemies in current room
    """
    choices = []
    for subroom in player.current_room.subrooms:
        choices.append(Choice(subroom, name=f"{subroom.name}"))

    if len(player.current_room.enemies) != 0:
        print("You can't escape a fight!")
        return False

    if len(choices) == 0:
        print("You cannot go anywhere!")
        return False

    choices.append(Choice(None, name="Cancel move"))
    room = inquirer.select(
        message="Which room do you want to go to?",
        choices=choices,
    ).execute()

    if room is None:  # returns the same thing, but doesn't change the player
        return False

    player.enter_room(room)
    return False  # so enemies in the new room doesn't directly attack the player


def heal_player(player: libplayer.Player, index: int):
    player.heal(player.consumables[index])
    pass


def use(player: libplayer.Player) -> bool:
    """
    Handle the use action.

    Returns:
        - Whether the player has used anything or not.
        He cannot use if: no consumables
    """
    consumables = []

    for index, consumable in enumerate(player.consumables):
        consumable.pretty_print()  # so the students know what each cons does
        consumables.append(Choice(index, name=f"{consumable.name}"))

    if len(consumables) == 0:
        print("You have no consumables.")
        return False

    print()
    consumables.append(Choice(-1, name="Cancel use"))
    selected = inquirer.select(
        message="What consumable do you want to use?",
        choices=consumables
    ).execute()

    if selected == -1:
        return False

    inquirer.select(
        message=f"How would you like to use {player.consumables[selected].name}?",
        choices=[
            Choice(heal_player, name="Heal"),
        ]
    ).execute()(player, selected)

    return True


def enemy_action(player: libplayer):
    """
    Handle enemy action.
    Each enemy attacks the player once per round.
    If the player dies, this function exits the runner.
    """
    print()
    for enemy in player.current_room.enemies:
        print(f"{enemy.name} is attacking {player.name}!")
        if enemy.attack_player(player):
            print(f"{enemy.name} has killed {player.name}...")
            exit(2)


# --- ENV SETUP ---
game_path = inquire_game_path()
game = libroom.load(game_path)

if game is None:
    print("This folder doesn't contain a valid game room!")
    exit(1)

player = libplayer.find_player_from_room(game)
if player is None:
    print("This folder doesn't contain a valid player!")
    exit(1)
else:
    print(f"Found player {player.name}, welcome! You are in {player.current_room.name}.")

# --- ACTION LOOP ---
while player.current_room.name.lower() != "exit":
    action = inquirer.select(
        message=f"You are in {player.current_room.name}. What do you want to do?",
        choices=[
            Choice(attack, name="Attack"),
            Choice(enemy_peek, name="Look at your enemies"),
            Choice(move, name="Move rooms"),
            Choice(subroom_peek, name="Look at where you can go"),
            Choice(use, name="Use Consumable"),
            Choice(player_peek, name="Look at your stats"),
        ],
    ).execute()

    print()

    if action(player):
        enemy_action(player)

    print()

print("You found the exit! Congratulations!")
