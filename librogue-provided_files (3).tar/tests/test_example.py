import sys
sys.path.append('..')
sys.path.append('.')
import librogue

def test_example():
    # This test will always pass
    assert True
